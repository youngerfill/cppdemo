
#include "part1.hpp"
#include "part2.hpp"

int main()
{
  DoPart1();
  DoPart2();
 
  return 0;
}

