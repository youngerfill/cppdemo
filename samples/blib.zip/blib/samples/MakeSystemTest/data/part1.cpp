#include <iostream>

using namespace std;

void DoPart1()
{
  cout << "This is Part 1." << endl;
}

