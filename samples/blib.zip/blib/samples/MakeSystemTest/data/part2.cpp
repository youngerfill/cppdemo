#include <iostream>

using namespace std;

void DoPart2()
{
  cout << "This is Part 2." << endl;
}
