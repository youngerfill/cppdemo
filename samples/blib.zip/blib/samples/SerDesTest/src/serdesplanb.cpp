
#include "SerDesPlanB.hpp"

//-----------------------------------------------
SerDesPlanB::SerDesPlanB(std::istream& instream, std::ostream& outstream) 
:SerDesStream(instream, outstream)
{
  indentLevel_ = 0;
}
  
//-----------------------------------------------
SerDesPlanB::SerDesPlanB(std::istream& instream) 
:SerDesStream(instream)
{
  indentLevel_ = 0;
}
  
//-----------------------------------------------
SerDesPlanB::SerDesPlanB(std::ostream& outstream) 
:SerDesStream(outstream)
{
  indentLevel_ = 0;
}

//-----------------------------------------------
void SerDesPlanB::IncIndent()
{
  indentLevel_++;
  indentString_ += "  ";
}
  
//-----------------------------------------------
void SerDesPlanB::DecIndent()
{
  if (indentLevel_)
  {
    indentLevel_--;
    indentString_.erase(indentLevel_*2, 2);
  }  
}  

//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const char& object)
{
  *pOutStream_ << indentString_ << name << " = " << object << std::endl;
}
    
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const short& object)
{
  *pOutStream_ << indentString_ << name << " = " << object << std::endl;
}
    
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const int& object)
{
  *pOutStream_ << indentString_ << name << " = " << object << std::endl;
}
    
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const long& object)
{
  *pOutStream_ << indentString_ << name << " = " << object << std::endl;
}
    
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const float& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const double& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const unsigned char& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const unsigned short& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const unsigned int& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const unsigned long& object)
{
  *pOutStream_ << indentString_ << name << " = "  << object << std::endl;
}
  
//-----------------------------------------------
bool SerDesPlanB::Write(const std::string& name, const std::string& object)
{
  *pOutStream_ << indentString_ << name << " = '"  << object << "'" << std::endl;
}  
  
//-----------------------------------------------
bool SerDesPlanB::WriteHead(const std::string& name, const std::string& className)
{
  *pOutStream_ << indentString_ << name;
  *pOutStream_  << " = object(" << className << ")" << std::endl;
  *pOutStream_  << indentString_ << "{" << std::endl;
  IncIndent();
}

//-----------------------------------------------
bool SerDesPlanB::WriteHeadPoly(const std::string& name, const std::string& className, unsigned long id)
{
  *pOutStream_ << indentString_ << name;
  *pOutStream_  << " = object(" << className << "," << id << ")" << std::endl;
  *pOutStream_  << indentString_ << "{" << std::endl;
  IncIndent();
}
  
//-----------------------------------------------
bool SerDesPlanB::WriteHeadArray(const std::string& name, std::size_t objectSize)
{
  *pOutStream_ << indentString_ << name;
  *pOutStream_  << " = array[" << objectSize << "]" << std::endl;
  *pOutStream_  << indentString_ << "{" << std::endl;
  IncIndent();
}

//-----------------------------------------------
bool SerDesPlanB::WriteHeadMap(const std::string& name, std::size_t objectSize)
{
  *pOutStream_ << indentString_ << name;
  *pOutStream_  << " = map[" << objectSize << "]" << std::endl;
  *pOutStream_  << indentString_ << "{" << std::endl;
  IncIndent();
}

//-----------------------------------------------
bool SerDesPlanB::WriteTail(const std::string& name)
{
  DecIndent();
  *pOutStream_ << indentString_ << "}" << std::endl;
}

  
//-----------------------------------------------
unsigned short SerDesPlanB::GetIndentLevel() const
{
  return indentLevel_;
}
  
//-----------------------------------------------
const std::string& SerDesPlanB::GetIndentString() const
{
  return indentString_;
}

