#if !defined SYNTAX_HPP
#define SYNTAX_HPP


template <typename T>
struct is_builtin
{
  enum { value = false };
};
  
template <> struct is_builtin<int>
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned long>
{ enum { value = true }; };
  
template <> struct is_builtin<long> 
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned short>
{ enum { value = true }; };
  
template <> struct is_builtin<short>
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned char>
{ enum { value = true }; };
  
template <> struct is_builtin<char>
{ enum { value = true }; };
  
template <> struct is_builtin<float>
{ enum { value = true }; };
  
template <> struct is_builtin<double>
{ enum { value = true }; };
  
template <> struct is_builtin<std::string>
{ enum { value = true }; };
  


#endif /* SYNTAX_HPP */ 
