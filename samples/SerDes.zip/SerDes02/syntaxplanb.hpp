#if !defined SYNTAXPLANB_HPP
#define SYNTAXPLANB_HPP

#include <iostream>
#include "syntax.hpp"


template <bool>
struct PlanBHelper
{
  template <typename T, typename SD>
  static bool Write(SD& serDes, const std::string& name, const T& object)
  {
    return object.Write(serDes, name);
  }  

  template <typename T, typename SD>
  static bool Write(SD& serDes, const T& object)
  {
    return object.Write(serDes);
  }  
};
  

template <>
struct PlanBHelper<true>
{
  template <typename T, typename SD>
  static bool Write(SD& serDes, const std::string& name, const T& object)
  {
    serDes.outStream_ << name << " = " << object << std::endl;
    return true; 
  }  

  template <typename T, typename SD>
  static bool Write(SD& serDes, const T& object)
  {
    serDes.outStream_ << object << std::endl;
    return true; 
  }  
};
  

template<typename T> 
struct SyntaxPlanB
{
  template <typename SD>
  static bool Write(SD& serDes, const std::string& name, const T& object) 
  { 
    PlanBHelper<is_builtin<T>::value>::Write(serDes, name, object);
  }

  template <typename SD>
  static bool Write(SD& serDes, const T& object) 
  { 
    PlanBHelper<is_builtin<T>::value>::Write(serDes, object);
  }
};


#endif /* SYNTAXPLANB_HPP */ 

