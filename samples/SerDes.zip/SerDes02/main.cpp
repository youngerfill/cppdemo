#include <iostream>
#include <stdlib.h>

#include "serdes.hpp"
#include "syntaxplanb.hpp"

using namespace std;



////////////////////
// 3rd party class
////////////////////
struct Class3rdParty
{
  Class3rdParty(int number, std::string name)
  {
    number_ = number;
    name_ = name;
  }  
  
  int number_;
  std::string name_;
};


////////////////////////////////////
// Make Class3rdParty serializable
////////////////////////////////////
template<> 
struct SyntaxPlanB<Class3rdParty>
{
  template <typename SD>
  static bool Write(SD& serDes, const std::string& name, const Class3rdParty& object) 
  { 
    serDes.Write("number", object.number_);
    serDes.Write("name", object.name_);
  }

  template <typename SD>
  static bool Write(SD& serDes, const Class3rdParty& object) 
  { 
    serDes.Write(object.number_);
    serDes.Write(object.name_);
  }
};


////////////////////
// app-specific class
////////////////////
struct ClassApp
{
  ClassApp(double temp, std::string place)
  {
    temp_ = temp;
    place_ = place;
  }  
  
  template <class SD>
  bool Write(SD& serDes, const std::string& name) const
  {
    serDes.Write("temp", temp_);
    serDes.Write("place", place_);
  }
    
  template <class SD>
  bool Write(SD& serDes) const
  {
    serDes.Write("temp", temp_);
    serDes.Write("place", place_);
  }
    
  double temp_;
  std::string place_;
};

//////////////////////////////////////////////
// app-specific class, derived from ClassApp
//////////////////////////////////////////////
struct ClassApp2 : public ClassApp
{
  ClassApp2(double temp, std::string place, std::string time)
  :ClassApp(temp, place)
  {
    time_ = time;
  }  
  
  template <class SD>
  bool Write(SD& serDes, const std::string& name) const
  {
    ClassApp::Write(serDes, name);
    serDes.Write("time", time_);
  }
    
  template <class SD>
  bool Write(SD& serDes) const
  {
    ClassApp::Write(serDes, name);
    serDes.Write("time", time_);
  }
    
  std::string time_;
};



//////////////////////////////////////////////
//             main()
//////////////////////////////////////////////
int main(int argc, char *argv[])
{
  SerDes<SyntaxPlanB> sdTje(cout);
  
  int testje = 5;
  sdTje.Write("testje", testje);
  sdTje.Write(testje);
  
  float Floatje = 3.14F;
  sdTje.Write("Floatje", Floatje);
  sdTje.Write(Floatje);
  
  cout << endl << endl;
  
  ClassApp myObject(17.31F, "garden");
  sdTje.Write("myObject", myObject);
  
  cout << endl << endl;
  
  ClassApp2 myObject2(20.63F, "kitchen", "yesterday");
  sdTje.Write("myObject2", myObject2);
  
  cout << endl << endl;

  ClassApp* pObject = &myObject2;
  sdTje.Write("*pObject", *pObject);
  
  cout << endl << endl;

  Class3rdParty theirObject(25, "NumberTwentyFive");
  sdTje.Write("theirObject", theirObject);
  
  cout << endl << endl;
  
  system("PAUSE");	
  return 0;
}


