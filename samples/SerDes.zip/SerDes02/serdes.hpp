#if !defined SERDES_HPP
#define SERDES_HPP

#include <iostream>
#include <string>

///////////////////////////
// is_builtin Trait class
///////////////////////////

template <typename T>
struct is_builtin
{
  enum { value = false };
};
  
template <> struct is_builtin<int>
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned long>
{ enum { value = true }; };
  
template <> struct is_builtin<long> 
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned short>
{ enum { value = true }; };
  
template <> struct is_builtin<short>
{ enum { value = true }; };
  
template <> struct is_builtin<unsigned char>
{ enum { value = true }; };
  
template <> struct is_builtin<char>
{ enum { value = true }; };
  
template <> struct is_builtin<float>
{ enum { value = true }; };
  
template <> struct is_builtin<double>
{ enum { value = true }; };
  
template <> struct is_builtin<std::string>
{ enum { value = true }; };
  


//////////////////////
// Syntax base class
//////////////////////

struct SyntaxBase
{
  ostream& outStream_;
  istream& inStream_;
};


/////////////
// SerDes
/////////////

template <typename Syntax, typename T>
struct SerDes
{
  static bool Write(Syntax& syntax, const std::string& name, const T& object)
  {
    return object.Write(syntax, name);
  }  
}

template <>
struct SerDes<int>
{
  static bool Write(Syntax& syntax, const std::string& name, const int& object)
  {
    return syntax.WriteBuiltIn(name, object);
  }  
}

  
///////////////////
// Free functions
///////////////////

template <typename Syntax, typename T>
bool WriteObject(Syntax& syntax, const std::string& name, const T& object)
{
  return SerDes<Syntax, T>::Write(syntax, name, object);
}


  
