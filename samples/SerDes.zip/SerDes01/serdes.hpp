#if !defined SERDES_HPP
#define SERDES_HPP

#include <iostream>
#include <string>

template <template <typename> class Syntax>
class SerDes
{
public:
  
  SerDes(std::istream& instream = std::cin, std::ostream& outstream = std::cout) 
  :inStream_(instream), outStream_(outstream)
  {}
  
  SerDes(std::ostream& outstream) 
  :inStream_(std::cin), outStream_(outstream)
  {}
  
  template <typename T>
  bool Write(const std::string& name, const T& object)
  {
    if (!Syntax<T>::Write(*this, name, object))
    {
      // TODO
      return false;
    }  
    return true;
  }  

  template <typename T>
  bool Write(const T& object)
  {
    if (!Syntax<T>::Write(*this, object))
    {
      // TODO
      return false;
    }  
    return true;
  }  

  template <typename T>
  bool Read(const std::string& name, T& object)
  {
    if (!Syntax<T>::Read(inStream_, name, object))
    {
      // TODO
      return false;
    }  
    return true;
  }  

  template <typename T>
  bool Read(const T& object)
  {
    if (!Syntax<T>::Read(inStream_, object))
    {
      // TODO
      return false;
    }  
    return true;
  }  
  
//protected:
  std::istream& inStream_;
  std::ostream& outStream_;
};

#endif /* SERDES_HPP */ 



