#if !defined SHAPES_HPP
#define SHAPES_HPP

struct Shape
{
  
};  


#endif /* SHAPES_HPP */ 

